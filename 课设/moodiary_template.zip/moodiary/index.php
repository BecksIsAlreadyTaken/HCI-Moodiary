<?php
// No direct access.
defined('_JEXEC') or die;
JLoader::import('joomla.filesystem.file');
JHtml::_('bootstrap.framework');
JHtml::_('bootstrap.loadCss');

// 所在位置上是否有模块发布
$showRightColumn = ($this->countModules('position-3') or $this->countModules('position-6') or $this->countModules('position-8'));

// 获取参数
$sitetitle           = $this->params->get('sitetitle');

/** @var JDocumentHtml $this */
?>

<!DOCTYPE html>
<html>
<head>	
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=3.0, user-scalable=yes"/>
	<meta name="HandheldFriendly" content="true" />
	<meta name="apple-mobile-web-app-capable" content="YES" />
	<jdoc:include type="head" />
	<link rel="stylesheet" href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->templates; ?>/files/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo $this->baseurl; ?>/templates/moodiary/files/bootstrap.css">
</head>

<body>
	<!-- 头部文件 -->
	<?php include_once('files.html');?> 
	<?php echo $sitetitle; ?>
	<!-- 主体内容 -->
	<div class="container">
		<div class="row">
			<div class="col-md-4">
			<nav id="t3-mainnav" class="wrap navbar navbar-default t3-mainnav">
				<jdoc:include type="modules" name="navbar"/>
			</nav>
			</div>
			<div class="col-md-8">
				<jdoc:include type="modules" name="search-bar"/>
			</div>
		</div>
		<jdoc:include type="component" />
		<div class="row">
			<div class="col-md-12">
				<jdoc:include type="modules" name="slider"/>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<jdoc:include type="modules" name="position-1"/>
			</div>
		</div>

	</div>
</body>
</html>